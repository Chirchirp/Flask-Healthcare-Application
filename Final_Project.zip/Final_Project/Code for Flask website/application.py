from flask import Flask, render_template, request, redirect, url_for
from flask_pymongo import PyMongo
import pandas as pd
from io import StringIO

application = Flask(__name__)
application.config['MONGO_URI'] = 'mongodb://localhost:27017/user_data'
mongo = PyMongo(application)

class User:
    def __init__(self, age, gender, total_income, utilities, entertainment, school_fees, shopping, healthcare):
        self.age = age
        self.gender = gender
        self.total_income = total_income
        self.utilities = utilities
        self.entertainment = entertainment
        self.school_fees = school_fees
        self.shopping = shopping
        self.healthcare = healthcare

@application.route('/')
def index():
    return render_template('index.html')

@application.route('/submit', methods=['POST'])
def submit():
    age = request.form.get('age')
    gender = request.form.get('gender')
    total_income = request.form.get('total_income')
    utilities = request.form.get('utilities')
    entertainment = request.form.get('entertainment')
    school_fees = request.form.get('school_fees')
    shopping = request.form.get('shopping')
    healthcare = request.form.get('healthcare')

    user = User(age, gender, total_income, utilities, entertainment, school_fees, shopping, healthcare)
    mongo.db.users.insert_one(user.__dict__)

    return redirect(url_for('index'))

@application.route('/export_csv')
def export_csv():
    users = mongo.db.users.find()
    df = pd.DataFrame(list(users))
    
    # Save DataFrame to CSV file
    csv_data = df.to_csv(index=False)
    
    # Create a response object to force download
    response = application.response_class(
        csv_data,
        mimetype='text/csv',
        headers={'Content-Disposition': 'attachment; filename=user_data.csv'}
    )

    return response

if __name__ == '__main__':
    application.run(debug=True)
